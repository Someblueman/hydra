#include "slug.h"
#include "slug.h"

int slugify(const char *input, char *output, size_t capacity)
{
    const unsigned char *p;
    size_t len = 0;
    int pending = 0;

    if (output == NULL || capacity == 0) {
        return -1;
    }

    output[0] = '\0';

    if (input == NULL) {
        return -1;
    }

    p = (const unsigned char *)input;

    while (*p != '\0') {
        unsigned char c = *p++;

        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9')) {
            if (pending && len > 0) {
                if (len + 1 > capacity - 1) {
                    output[0] = '\0';
                    return -1;
                }
                output[len++] = '-';
            }
            pending = 0;

            if (c >= 'A' && c <= 'Z') {
                c = (unsigned char)(c + ('a' - 'A'));
            }

            if (len + 1 > capacity - 1) {
                output[0] = '\0';
                return -1;
            }
            output[len++] = (char)c;
        } else {
            pending = 1;
        }
    }

    output[len] = '\0';
    return 0;
}
